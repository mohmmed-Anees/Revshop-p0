package com.RevShop.DAO.com.main;

import com.RevShop.DAO.UserDAO;
import com.RevShop.DAOImpl.productDAOImpl;
import com.RevShop.DAOImpl.userDAOImpl;
import com.RevShop.entity.Cart;
import com.RevShop.entity.CartItem;
import com.RevShop.entity.Product;
import com.RevShop.entity.buyers;
import com.RevShop.serviceImpl.productServiceImpl;
import com.RevShop.service.*;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

public class main {

    public static void main(String[] args) {

//    	productDAOImpl productDAO = new productDAOImpl();
//
//        // Create a Service object
//        productService productService = new productServiceImpl();

        // 1. Add Product Test
//       Product product1 = new Product(2, 2, "sneakers", "All kind of sneakers available", BigDecimal.valueOf(2000.00), BigDecimal.valueOf(1900.00), null, "laptop_image_url", 10, "fashion",new Timestamp(System.currentTimeMillis()));
//        productService.addProduct(product1);
//        System.out.println("Product added: " + product1);

        // 2. Update Product Test
//        product1.setPrice(BigDecimal.valueOf(950.00));
//        product1.setDiscountedPrice(BigDecimal.valueOf(1000.00));
//        productService.updateProduct(product1);
//        System.out.println("Product updated: " + product1);
//
//        // 3. Update Product Quantity Test
//        productService.updateProductByQuantity(product1.getProductId(), 15);
//        System.out.println("Product quantity updated: Product ID " + product1.getProductId() + " now has quantity 15.");
//
//        // 4. Get Product by ID Test
//        Product fetchedProduct = productService.getProductById(product1.getProductId());
//        System.out.println("Fetched product by ID: " + fetchedProduct);
//
//        // 5. Get All Products Test
//        List<Product> allProducts = productService.getAllProducts();
//        System.out.println("All products: " + allProducts);
//
        // 6. Get Products by Seller ID Test
//        List<Product> sellerProducts = productService.getProductBySellerId(1);
//        System.out.println("Products by seller ID 1: " + sellerProducts);
//
//        // 7. Delete Product Test
//        productService.deleteProduct(product1.getProductId());
//        System.out.println("Product deleted with ID: " + product1.getProductId());
//        UserDAO userdao = new userDAOImpl();
//        userServiceImpl userService = new userServiceImpl();
//
//       
//        buyers newBuyer = new buyers();
//        newBuyer.setName("John Doe");
//        newBuyer.setEmail("johndoe@example.com");
//        newBuyer.setPassword("securePassword");
//        newBuyer.setPhoneNumber(9876543210L);
//        newBuyer.setAddress("123 Main Street, Cityville");
//        newBuyer.setCreatedAt(new Timestamp(System.currentTimeMillis()));
//        newBuyer.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
//
//        
//        String registrationResult = userService.isRegistered(newBuyer);
//
//        
//        if ("User already registered!".equals(registrationResult)) {
//            System.out.println("User is already registered.");
//        } else {
//            System.out.println("User registration successful!");
//
//            // Fetch and display the user details to verify the database operation
//            buyers registeredBuyer = userService.getUserDetails(newBuyer.getBuyerId());
//            System.out.println("User Details: " + registeredBuyer);
//        }
    	
    	Cart cart = new Cart();

        // Adding items to the cart
        CartItem item1 = new CartItem(101, "Laptop", 1, 1000.00, 900.00);
        CartItem item2 = new CartItem(102, "Smartphone", 2, 600.00, 550.00);
        
        cart.addItem(item1);
        cart.addItem(item2);
        
        // Display cart contents
        System.out.println(cart);

        // Update quantity
//        cart.updateQuantity(101, 2);  // Increase Laptop quantity to 2
//
//        // Display updated cart contents
//        System.out.println("After updating quantity:");
//        System.out.println(cart);
//
//        // Remove an item
//        cart.removeItem(102);
//
//        // Display updated cart after removal
//        System.out.println("After removing an item:");
//        System.out.println(cart);
    }
}
