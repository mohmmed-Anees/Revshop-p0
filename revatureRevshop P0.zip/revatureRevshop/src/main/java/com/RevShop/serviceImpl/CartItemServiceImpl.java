package com.RevShop.serviceImpl;

import java.util.List;

import com.RevShop.DAO.CartItemDAO;
import com.RevShop.DAOImpl.CartItemDAOImpl;
import com.RevShop.entity.CartItem;
import com.RevShop.service.CartItemServices;

public class CartItemServiceImpl implements CartItemServices{

	private CartItemDAO cartItemDAO;

    public CartItemServiceImpl() {
        this.cartItemDAO = new CartItemDAOImpl();
    }

    @Override
    public void addToCart(CartItem cartItem) {
        cartItemDAO.addToCart(cartItem);
    }

    @Override
    public void updateCartItem(CartItem cartItem) {
        cartItemDAO.updateCartItem(cartItem);
    }

    @Override
    public List<CartItem> getCartItems(int buyerId) {
        return cartItemDAO.getCartItems(buyerId);
    }

    @Override
    public void removeFromCart(int buyerId, int productId) {
        cartItemDAO.removeFromCart(buyerId, productId);
    }

    @Override
    public void clearCart(int buyerId) {
        cartItemDAO.clearCart(buyerId);
    }

    @Override
    public CartItem getCartItem(int buyerId, int productId) {
        return cartItemDAO.getCartItem(buyerId, productId);
    }

}
